package com.example.timer;

import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.os.Bundle;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    private EditText time;  // Keep this as the class member
    private long start, stop, diff;
    private double sec;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button startButton = findViewById(R.id.startButton);
        Button stopButton = findViewById(R.id.stopButton);
        time = findViewById(R.id.time);  // Initialize the class member

        startButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                start = System.currentTimeMillis();
            }
        });

        stopButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                stop = System.currentTimeMillis();
                diff = stop - start;
                sec = diff / 1000.0;  // Ensure floating-point division
                time.setText(String.valueOf(sec));
            }
        });
    }
}